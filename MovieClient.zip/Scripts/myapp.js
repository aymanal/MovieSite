﻿var app = angular.module('myApp', ['ui.router']);

app.config(function ($stateProvider, $urlRouterProvider) {
    $stateProvider
        .state('Default', {
            url: '/Default',
            templateUrl: '../Default.html'
        })
        .state('EditData', {
            url: '/EditData',
            templateUrl: '../Edit.html'
        })


});



app.factory("myFactory", function () {
    var savedData = {}
    
    function set(data) {
        savedData = data;
    }
    function get() {
        return savedData;
    }

    return {
        set: set,
        get: get
    }
})




app.controller("MovieController", function($scope, $location, myFactory, $http){
    $http.get('http://localhost:52323/api/Movie').success(function (response) {
        $scope.result = response;
        $scope.Movies = $scope.result;
    });



        $scope.Edit = function (d) {
            myFactory.set(d);
            $location.path('/EditData');

        }
    });



app.controller("editCtrl", function ($scope, $location, myFactory) {
    $scope.Movies = myFactory.get();
    $scope.Back = function () {
        $location.path('/Default');
    }
})