﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MovieSite.Models
{
    public class Movie
    {
        public string Id
        {
            set;
            get;
        }
        public string Image
        {
            set;
            get;
        }
        public string Title
        {
            set;
            get;
        }
        public int Seasons
        {
            set;
            get;
        }
        public int Views
        {
            set;
            get;
        }
        public string description
        {
            set;
            get;
        }
    }
}