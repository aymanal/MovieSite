﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MovieSite.Models
{
    public class MovieList
    {
        public List<Movie> findAll()
        {

            List<Movie> result = new List<Movie>();
            result.Add(new Movie { Id = "M01", Title = "Game Of Thrones", Seasons = 8, Views = 3000000,
                Image = "https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/best-game-of-thrones-season-8-fan-theories-1554917935.jpg?crop=0.501xw:1.00xh;0.256xw,0&resize=480:*"
            ,description= "is an American fantasy drama television series created by David Benioff and D. B. Weiss for HBO. It is an adaptation of A Song of Ice and Fire, George R. R. Martin's series of fantasy novels, the first of which is A Game of Thrones. The show is filmed in Belfast and elsewhere in Northern Ireland, Canada, Croatia, Iceland, Malta, Morocco, Scotland, Spain, and the United States.[1] The series premiered on HBO in the United States on April 17, 2011, and will conclude with its eighth season, which premiered on April 14, 2019"
            }); 
            result.Add(new Movie { Id = "M02", Title = "Breaking bad", Seasons = 5, Views = 2800000,
            Image= "https://brobible.files.wordpress.com/2018/11/bryan-cranston-breaking-bad-movie-dan-patrick.jpg?quality=90&w=650" , description= "is an American neo-western crime drama television series created and produced by Vince Gilligan. The show originally aired on AMC for five seasons, from January 20, 2008 to September 29, 2013. Set and filmed in Albuquerque, New Mexico, the series tells the story of Walter White (Bryan Cranston), a struggling and depressed high school chemistry teacher who is diagnosed with lung cancer. Together with his former student Jesse Pinkman (Aaron Paul), White turns to a life of crime by producing and selling crystallized methamphetamine to secure his family's financial future before he dies, while navigating the dangers of the criminal world. The title comes from the Southern colloquialism breaking bad, meaning to raise hell or turn to a life of crime.[5]"
            });
            result.Add(new Movie { Id = "M03", Title = "La casa de papel", Seasons = 3, Views = 250000,
            Image= "https://m.media-amazon.com/images/M/MV5BMzBlY2QzNzYtMWU1NS00NjFkLWJiMzItYmM3YTc4MDFjNDQwXkEyXkFqcGdeQXVyMTA0MjU0Ng@@._V1_UX182_CR0,0,182,268_AL_.jpg" , description= " is a Spanish heist television series created by Álex Pina. It revolves around a long-prepared, multi-day assault on the Royal Mint of Spain. It was initially intended as a limited series and premiered on 2 May 2017 on Spanish network Antena 3. Antena 3 distributed the series in Spain before Netflix acquired it in late 2017; Netflix edited the series and re-released it worldwide. Money Heist stars Úrsula Corberó, Itziar Ituño, Álvaro Morte, Miguel Herrán, Paco Tous, Pedro Alonso, and Alba Flores.[1] In April 2018, Netflix renewed the series for a third part, which is set to be released on 19 July 2019."
            });

            return result;
        }
        public Movie find(string id)
        {
            return findAll().Single(m => m.Id.Equals(id));
        }
    }
}