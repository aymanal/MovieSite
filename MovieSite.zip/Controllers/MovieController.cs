﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MovieSite.Models;

namespace MovieSite.Controllers
{
    public class MovieController : ApiController
    {
        // GET: api/Movie
        //get all elements
        public IEnumerable<Movie> Get()
        {
            MovieList pm = new MovieList();
            return pm.findAll().AsEnumerable();
        }

       //get by one element
        public Movie Get(string id)
        {
            MovieList pm = new MovieList();

            return pm.find(id);
        }

       
    }
}
